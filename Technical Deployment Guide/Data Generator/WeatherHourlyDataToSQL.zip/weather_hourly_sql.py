import sys
import os
sys.path.insert(0, ".")
sys.path.insert(0, 'requests.zip')
sys.path.insert(0, 'pytz.zip')
import requests
from datetime import datetime, timedelta
from cStringIO import StringIO
from collections import defaultdict
import pyodbc
import time
from pytz import timezone

def round_time_up(tm):
    upmins = math.ceil(float(tm.minute)/5)*5
    diffmins = upmins - tm.minute
    newtime = tm + timedelta(minutes=diffmins)
    newtime = newtime.replace(second=0, microsecond=0)
    #newtime = tm - datetime.timedelta(minutes=tm.minute - round(tm.minute, -1), seconds tm.second, microseconds=tm.microsecond)
    print  "crawler start time after round up: {start_time}".format(start_time=newtime.strftime("%Y-%m-%d %H:%M:%S"))
    return newtime

class EventHubWrapper:

    def __init__(self, driver, server, database, user, password, data_table, log_table):
        self.time_zone = timezone("UTC")
        try:
            self.conn = pyodbc.connect("DRIVER={driver};SERVER={server};DATABASE={database};UID={user};"
                                       "PWD={password}".format(driver=driver, server=server, database=database,
                                                               user=user, password=password))
            self.cursor = self.conn.cursor()
        except pyodbc.Error as error:
            print error
            exit()
        self.log_table = log_table
        self.data_table = data_table
        self.datetime = datetime.now(self.time_zone)
        self.date = self.datetime.strftime("%Y%m%d")
        self.events = defaultdict(dict)

    def get_latest_success_events(self):
        start_datetime = self.datetime - timedelta(hours=MAX_HISTORY_HOURS)
        success_events = self.cursor.execute("select PTID, utcTimeStamp from "+self.log_table+" where utcTimeStamp >= '"+
                                             start_datetime.strftime("%Y-%m-%d %H:%M:%S")+"' and utcTimeStamp <= '" +
                                             self.datetime.strftime("%Y-%m-%d %H:%M:%S")+"' and Flag='success'")
        for event in success_events:
            ptid, utcTimestamp = event
            self.events[utcTimestamp.strftime("%Y-%m-%d %H:%M:%S")][str(ptid)] = 1

    def send_log(self, utcTimestamp, ptid, temperature, event_time, flag, detail):
        self.cursor.execute("insert into "+self.log_table+" values('"+utcTimestamp.strftime("%Y-%m-%d %H:%M:%S")+"',"
							+str(ptid)+","+str(temperature)+",0,'"+event_time.strftime("%Y-%m-%d %H:%M:%S") +
                            "','" + str(flag)+"','"+str(detail)+"')")
        content_to_push = '{"utcTimeStamp": "'+ utcTimestamp.strftime("%Y-%m-%d %H:%M:%S") + '","PTID": "' +str(ptid) +',"temperature":"'+str(temperature)+'}'
        print "log", event_time, flag, detail, content_to_push
        self.cursor.commit()

    def send_event(self, utcTimestamp, ptid):
		#self.cursor.execute("{call sp_Data_simulator_weather(?,?)}",(utcTimestamp),(ptid))
		self.cursor.execute("execute sp_Data_simulator_weather_forecast @dt='%s',@ptid=%d"%(utcTimestamp,ptid))

		#self.cursor.execute("execute sp_Data_simulator_weather @dt='%s' @ptid=%s"%utcTimestamp%ptid)

        # content_to_push = '{"utcTimeStamp": "'+utcTimestamp.strftime("%Y-%m-%d %H:%M:%S")+'","PTID": "'+str(ptid)+'","temperature": '+str(temperature)+'}'
        # print "insert ", datetime.now(), content_to_push

    def obtain_data(self,date):
        data_cursor = self.cursor.execute("execute sp_Data_simulator_weather_getdata @dt = '%s'"%date)
        return data_cursor

    def print_data(self,data_cursor):
        rows = data_cursor.fetchall()
        print len(rows)
        for row in rows:
            print row[0], row[1], row[2]

    def clean_up(self):
        self.conn.close()

    def push_data(self, data_content):
        push_count = MAX_NUMBER_RESULTS
        rows = data_cursor.fetchall()
        print len(rows)
        if len(rows) == 0:
            print "data_contents is None"
        else:
            for row in rows:
                print row[0], row[1], row[2]
                #record_date_time = self.time_zone.localize(datetime.strptime(row["timestamp"], "%m/%d/%Y %H:%M:%S"))
                record_date_time = self.time_zone.localize(row[0])
                #record_date_time = self.time_zone.localize(datetime.strptime(record_time, "%m/%d/%Y %H:%M:%S"))
                if (self.datetime - record_date_time).total_seconds()/3600.0 < MAX_HISTORY_HOURS - 1 and \
                        (record_date_time.minute % 60 == 0 and record_date_time.second == 0) and \
                        ((self.datetime - record_date_time).total_seconds()/3600.0 >= 0 ):
                    if str(row[1]) not in self.events[record_date_time.strftime("%Y-%m-%d %H:%M:%S")]:
                        time_to_try = 10
                        while time_to_try > 0 and push_count > 0:
                            try:
                                push_count -= 1
                                event_time = datetime.now()
                                self.send_event(row[0], row[1])
                                self.send_log(record_date_time, row[1], row[2], event_time,
                                              "success", "insert try "+str(time_to_try))
                                break
                            except pyodbc.IntegrityError as error:
                                print error
                                time_to_try -= 1
                            except:
                                time_to_try -= 1
                                self.send_log(record_date_time, row[1], row[2], event_time,
                                              "fail", "insert try "+str(time_to_try))
                    if push_count <= 0:
                        break

if __name__ == "__main__":
    # initialize program glob parameters
    MAX_NUMBER_RESULTS = int(os.environ["MaxNumberResults"])
    MAX_HISTORY_HOURS = int(os.environ["MaxHistoryHours"])
    MAX_DAILY_GAP_HOURS = int(os.environ["MaxDailyGapHours"])

    # initialize the crawler
    crawler = EventHubWrapper(driver = os.environ["SqlDriver"],
                              server = os.environ["SqlServer"] + os.environ["SqlServerSuffix"],
                              database= os.environ["SqlDatabase"],
                              user = os.environ["SqlUser"],
                              password = os.environ["SqlPassword"],
                              data_table = os.environ["WeatherDataTable"],
                              log_table = os.environ["WeatherSqlLogTable"])

    crawler_start_time = crawler.datetime
    print "crawler start time: {start_time}".format(start_time=crawler_start_time.strftime("%Y-%m-%d %H:%M:%S"))
    #crawler_time = round_time_up(crawler_start_time)

    # get date for today and yesterday
    today = crawler_start_time.strftime("%Y%m%d")
    yesterday = (crawler_start_time - timedelta(days=1)).strftime("%Y%m%d")

    # get most recent successfully pushed events
    crawler.get_latest_success_events()

    # deal with yesterday's unprocessed data
    if crawler_start_time < crawler.time_zone.localize(datetime.strptime(today+" "+str(MAX_DAILY_GAP_HOURS)+":00:00", "%Y%m%d %H:%M:%S")):
        print crawler_start_time, crawler.time_zone.localize(datetime.strptime(today+" "+str(MAX_DAILY_GAP_HOURS)+":00:00", "%Y%m%d %H:%M:%S"))
        data_cursor = crawler.obtain_data(yesterday)
        crawler.push_data(data_cursor)

    # deal with today's unprocessed data
    data_cursor = crawler.obtain_data(today)
    crawler.push_data(data_cursor)

    # clean up connections
    crawler.clean_up()
